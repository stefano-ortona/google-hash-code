/*
 * MIT License

 * Copyright (c) 2016
 */
package google.com.ortona.hashcode;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import google.com.ortona.hashcode.data_center.logic.MinimalDatacenterAllocation;
import google.com.ortona.hashcode.data_center.logic.model.Server;


/**
 * Hello world!
 *
 * @author <a href="mailto:${developer-email}">${developer-name}</a>
 * @version 1.0-SNAPSHOT
 **/
public class App {

    private static final Logger LOGGER = LoggerFactory.getLogger(App.class);

    public static void main(final String[] args) {
        List<Server> servers = new ArrayList<Server>();
        

    }

}