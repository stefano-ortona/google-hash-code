package google.com.ortona.hashcode.pizza.model;

public enum Ingredient {
  m, t;
}
