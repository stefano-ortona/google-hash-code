package google.com.ortona.hashcode.data_center.logic;

import google.com.ortona.hashcode.UtilsFileServer;

public class OptimizeDataCenterLogic {

    UtilsFileServer fr = new UtilsFileServer("dc.in");

}
