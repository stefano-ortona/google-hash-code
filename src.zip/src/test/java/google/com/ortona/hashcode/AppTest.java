/*
 * MIT License

 * Copyright (c) 2016
 */
package google.com.ortona.hashcode;

import org.junit.Assert;
import org.junit.Test;

/**
 * Unit test
 */
public class AppTest {
  @Test
  public void testScratch() {
    Assert.assertTrue(true);
  }
}
